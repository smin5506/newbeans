from django.apps import AppConfig


class NewbeansConfig(AppConfig):
    name = 'newbeans'
